#!/usr/bin/php -q
<?php

error_reporting(-1);

ini_set('display_errors', 1);

require __DIR__ . "/../gump.class.php";

$data = ['street' => '6 Avondans Road'];

$validated = GUMP::is_valid($data, ['street' => 'required|street_address']);

if($validated === true) {
	echo "Valid Street Address\n";
} else {
	print_r($validated);
}