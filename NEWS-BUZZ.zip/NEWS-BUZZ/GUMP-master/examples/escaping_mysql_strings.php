#!/usr/bin/php -q
<?php

require __DIR__ . "/../gump.class.php";

$validator = new GUMP();

$_POST = ['username' => "my username", 'password' => "' OR ''='"];

$validator->sanitize($_POST);

$filters = ['username' => 'noise_words', 'password' => 'trim|strtolower|addslashes'];

print_r($validator->filter($_POST, $filters));

// OR (If you have a mysql connection)

$validator->sanitize($_POST);

$_POST = ['username' => "my username", 'password' => "' OR ''='"];

$filters = ['username' => 'noise_words', 'password' => 'trim|strtolower'];

$validator->filter($_POST, $filters);

echo mysql_real_escape_string($_POST['password']);
