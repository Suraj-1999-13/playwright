#!/usr/bin/php -q
<?php

require __DIR__ . "/../gump.class.php";

$validator = new GUMP();

$validator->validation_rules(['comment' => 'required|max_len,500']);

$validator->filter_rules(['comment' => 'basic_tags']);

// Valid Data
$_POST = ['comment' => '<strong>this is freaking awesome</strong><script>alert(1);</script>'];


$_POST = $validator->run($_POST);

print_r($_POST);