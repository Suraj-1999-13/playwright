#!/usr/bin/php -q
<?php

error_reporting(-1);

ini_set('display_errors', 1);

require __DIR__ . "/../gump.class.php";

$data = ['str' => null];

$rules = ['str' => 'required'];

GUMP::set_field_name("str", "Street");

$validated = GUMP::is_valid($data, $rules);

if($validated === true) {
	echo "Valid Street Address\n";
} else {
	print_r($validated);
}