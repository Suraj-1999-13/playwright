#!/usr/bin/php -q
<?php

require __DIR__ . "/../gump.class.php";

$_FILES = ['attachments' => ['name'     => ["test1.png"], 'type'     => ["image/png"], 'tmp_name' => ["/tmp/phpmFkEUe"], 'error'    => [0], 'size'     => [9855]]];

$errors = [];

$length = count($_FILES['attachments']['name']);

for($i = 0; $i < $length; ++$i) {
	$struct = ['name'     => $_FILES['attachments']['name'][$i], 'type'     => $_FILES['attachments']['type'][$i], 'tmp_name' => $_FILES['attachments']['tmp_name'][$i], 'error'    => $_FILES['attachments']['error'][$i], 'size'     => $_FILES['attachments']['size'][$i]];
	
	$validated = GUMP::is_valid($struct, ['name'     => 'required', 'type'     => 'required', 'tmp_name' => 'required', 'size'     => 'required|numeric']);	
	
	if($validated !== true) {
		$errors[] = $validated;
	}
}

print_r($errors);