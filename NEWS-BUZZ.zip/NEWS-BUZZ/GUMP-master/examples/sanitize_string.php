#!/usr/bin/php -q
<?php

require __DIR__ . "/../gump.class.php";

$validator = new GUMP();

$_POST = ['string' => '<script>alert(1); $("body").remove(); </script>'];

$filters = ['string' => 'sanitize_string'];

print_r($validator->filter($_POST, $filters));
