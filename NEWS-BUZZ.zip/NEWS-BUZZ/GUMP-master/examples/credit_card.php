#!/usr/bin/php -q
<?php

require __DIR__ . "/../gump.class.php";

$validator = new GUMP();

$_POST = ['cc' => '987230234-2498234-24234-23'];

$rules = ['cc' => 'valid_cc'];

print_r($validator->validate($_POST, $rules));
