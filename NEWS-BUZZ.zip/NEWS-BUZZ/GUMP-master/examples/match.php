#!/usr/bin/php -q
<?php

require __DIR__ . "/../gump.class.php";

$data = ['username'         => "myusername", 'password'         => "mypassword", 'password_confirm' => "mypa33word"];

$is_valid = GUMP::is_valid($data, ['username'         => 'required|alpha_numeric', 'password'         => 'required|max_len,100|min_len,6', 'password_confirm' => 'equalsfield,password']);

if($is_valid === true) {
	// continue
} else {
	print_r($is_valid);
}
