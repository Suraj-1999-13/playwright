<?php
declare(strict_types=1);

session_start();?>

<?php

session_destroy();

header('Location: index');

?>
