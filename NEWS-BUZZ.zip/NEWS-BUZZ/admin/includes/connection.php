<?php
declare(strict_types=1);

define('DB_SERVER','db');
define('DB_USER','root');
define('DB_PASS' ,'rootpassword');
define('DB_NAME','latest');
$conn = mysqli_connect(DB_SERVER,DB_USER,DB_PASS,DB_NAME);
// Check connection
if (mysqli_connect_errno() !== 0)
{
 echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
?>
