<?php declare(strict_types=1);

include __DIR__ . '/includes/adminheader.php';
?>
    <div id="wrapper">
<?php ?>
       <?php include __DIR__ . '/includes/adminnav.php';?>
        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                        <div class="col-xs-4">
            <a href="publishnews" class="btn btn-primary">Add New</a>
            </div>
                            ALL POSTS
                        </h1>
                         

<?php if ($_SESSION['role'] == 'superadmin') {
    ?>
<div class="row">
<div class="col-lg-12">
        <div class="table-responsive">

<form action="" method="post">
            <table class="table table-bordered table-striped table-hover">


            <thead>
                    <tr>
                        <th>ID</th>
                        <th>Author</th>
                        <th>Title</th>
                        <th>Status</th>
                        <th>Image</th>
                        <th>Tags</th>
                        <th>Date</th>
                        <th>View Post</th>
                        <th>Edit</th>
                        <th>Delete</th>
                        <th>Publish</th>
                    </tr>
                </thead>
                <tbody>

                 <?php 
    $query = "SELECT * FROM posts ORDER BY id DESC";
    ($run_query = mysqli_query($conn, $query)) || die(mysqli_error($conn));
    if (mysqli_num_rows($run_query) > 0) {
    while ($row = mysqli_fetch_array($run_query)) {
        $post_id = $row['id'];
        $post_title = $row['title'];
        $post_author = $row['author'];
        $post_date = $row['postdate'];
        $post_image = $row['image'];
        $post_content = $row['content'];
        $post_tags = $row['tag'];
        $post_status = $row['status'];
    
        echo "<tr>";
        echo sprintf('<td>%s</td>', $post_id);
        echo sprintf('<td>%s</td>', $post_author);
        echo sprintf('<td>%s</td>', $post_title);
        echo sprintf('<td>%s</td>', $post_status);
        echo sprintf('<td><img  width=\'100\' src=\'../allpostpics/%s\' alt=\'Post Image\' ></td>', $post_image);
        echo sprintf('<td>%s</td>', $post_tags);
        echo sprintf('<td>%s</td>', $post_date);
        echo sprintf('<td><a href=\'post.php?post=%s\' style=\'color:green\'>See Post</a></td>', $post_id);
        echo sprintf('<td><a href=\'editposts.php?id=%s\'><span class=\'glyphicon glyphicon-edit\' style=\'color: #265a88;\'></span></a></td>', $post_id);
        echo sprintf('<td><a onClick="javascript: return confirm(\'Are you sure you want to delete this post?\')" href=\'?del=%s\'><i class=\'fa fa-times\' style=\'color: red;\'></i>delete</a></td>', $post_id);
        echo sprintf('<td><a onClick="javascript: return confirm(\'Are you sure you want to publish this post?\')"href=\'?pub=%s\'><i class=\'fa fa-times\' style=\'color: red;\'></i>publish</a></td>', $post_id);
    
        echo "</tr>";
    
    }
    }
    else {
        echo "<script>alert('Not any news yet! Start Posting now');
    window.location.href= 'publishnews.php';</script>";
    }
    ?>


                </tbody>
            </table>
</form>
</div>
</div>
</div>

 <?php 
    if (isset($_GET['del'])) {
            $post_del = mysqli_real_escape_string($conn, (string) $_GET['del']);
            $del_query = sprintf('DELETE FROM posts WHERE id=\'%s\'', $post_del);
            ($run_del_query = mysqli_query($conn, $del_query)) || die (mysqli_error($conn));
            if (mysqli_affected_rows($conn) > 0) {
                echo "<script>alert('post deleted successfully');
            window.location.href='posts.php';</script>";
            }
            else {
             echo "<script>alert('error occured.try again!');</script>";   
            }
            }

    if (isset($_GET['pub'])) {
    $post_pub = mysqli_real_escape_string($conn,(string) $_GET['pub']);
    $pub_query = sprintf('UPDATE posts SET status=\'published\' WHERE id=\'%s\'', $post_pub);
    ($run_pub_query = mysqli_query($conn, $pub_query)) || die (mysqli_error($conn));
    if (mysqli_affected_rows($conn) > 0) {
        echo "<script>alert('post published successfully');
            window.location.href='posts.php';</script>";
    }
    else {
     echo "<script>alert('error occured.try again!');</script>";   
    }
    }
} elseif ($_SESSION['role'] == 'admin') {
    ?>
    <div class="row">
<div class="col-lg-12">
        <div class="table-responsive">

<form action="" method="post">
            <table class="table table-bordered table-striped table-hover">


            <thead>
                    <tr>
                        <th>ID</th>
                        <th>Author</th>
                        <th>Title</th>
                        <th>Status</th>
                        <th>Image</th>
                        <th>Tags</th>
                        <th>Date</th>
                        <th>View Post</th>
                        <th>Edit</th>
                        <th>Delete</th>
                        <th>Publish</th>
                    </tr>
                </thead>
                <tbody>

                 <?php 
    $currentuser = $_SESSION['firstname'];
    $query = sprintf('SELECT * FROM posts WHERE author = \'%s\' ORDER BY id DESC', $currentuser);
    ($run_query = mysqli_query($conn, $query)) || die(mysqli_error($conn));
    if (mysqli_num_rows($run_query) > 0) {
    while ($row = mysqli_fetch_array($run_query)) {
        $post_id = $row['id'];
        $post_title = $row['title'];
        $post_author = $row['author'];
        $post_date = $row['postdate'];
        $post_image = $row['image'];
        $post_content = $row['content'];
        $post_tags = $row['tag'];
        $post_status = $row['status'];
    
        echo "<tr>";
        echo sprintf('<td>%s</td>', $post_id);
        echo sprintf('<td>%s</td>', $post_author);
        echo sprintf('<td>%s</td>', $post_title);
        echo sprintf('<td>%s</td>', $post_status);
        echo sprintf('<td><img  width=\'100\' src=\'../allpostpics/%s\' alt=\'Post Image\' ></td>', $post_image);
        echo sprintf('<td>%s</td>', $post_tags);
        echo sprintf('<td>%s</td>', $post_date);
        echo sprintf('<td><a href=\'post.php?post=%s\' style=\'color:green\'>See Post</a></td>', $post_id);
        echo sprintf('<td><a href=\'editposts.php?id=%s\'><span class=\'glyphicon glyphicon-edit\' style=\'color: #265a88;\'></span></a></td>', $post_id);
        echo sprintf('<td><a onClick="javascript: return confirm(\'Are you sure you want to delete this post?\')" href=\'?del=%s\'><i class=\'fa fa-times\' style=\'color: red;\'></i>delete</a></td>', $post_id);
        echo sprintf('<td><a onClick="javascript: return confirm(\'Are you sure you want to publish this post?\')"href=\'?pub=%s\'><i class=\'fa fa-times\' style=\'color: red;\'></i>publish</a></td>', $post_id);
    
        echo "</tr>";
    
    }
    }
    else {
        echo "<script>alert('You have not posted any news yet! Start Posting now');
    window.location.href= 'publishnews.php';</script>";
    }
    ?>


                </tbody>
            </table>
</form>
</div>
</div>
</div>

 <?php 
    if (isset($_GET['del'])) {
            $post_del = mysqli_real_escape_string($conn, (string) $_GET['del']);
            $del_query = sprintf('DELETE FROM posts WHERE id=\'%s\'', $post_del);
            ($run_del_query = mysqli_query($conn, $del_query)) || die (mysqli_error($conn));
            if (mysqli_affected_rows($conn) > 0) {
                echo "<script>alert('post deleted successfully');
            window.location.href='posts.php';</script>";
            }
            else {
             echo "<script>alert('error occured.try again!');</script>";   
            }
            }
    if (isset($_GET['pub'])) {
    $post_pub = mysqli_real_escape_string($conn,(string) $_GET['pub']);
    $pub_query = sprintf('UPDATE posts SET status=\'published\' WHERE id=\'%s\'', $post_pub);
    ($run_pub_query = mysqli_query($conn, $pub_query)) || die (mysqli_error($conn));
    if (mysqli_affected_rows($conn) > 0) {
        echo "<script>alert('post published successfully');
            window.location.href='posts.php';</script>";
    }
    else {
     echo "<script>alert('error occured.try again!');</script>";   
    }
    }
} else {
    ?>
<div class="row">
<div class="col-lg-12">
        <div class="table-responsive">

<form action="" method="post">
            <table class="table table-bordered table-striped table-hover">
 <thead>
                    <tr>
                        <th>Title</th>
                        <th>Status</th>
                        <th>Image</th>
                        <th>Tags</th>
                        <th>Date</th>
                        <th>View Post</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>

                 <?php
                 $currentuser = $_SESSION['firstname'];

$query = sprintf('SELECT * FROM posts WHERE author = \'%s\' ORDER BY id DESC', $currentuser);
($run_query = mysqli_query($conn, $query)) || die(mysqli_error($conn));
if (mysqli_num_rows($run_query) > 0) {
while ($row = mysqli_fetch_array($run_query)) {
    $post_id = $row['id'];
    $post_title = $row['title'];
    $post_author = $row['author'];
    $post_date = $row['postdate'];
    $post_image = $row['image'];
    $post_content = $row['content'];
    $post_tags = $row['tag'];
    $post_status = $row['status'];

    echo "<tr>";
    echo sprintf('<td>%s</td>', $post_title);
    echo sprintf('<td>%s</td>', $post_status);
    echo sprintf('<td><img  width=\'100\' src=\'../allpostpics/%s\' alt=\'Post Image\' ></td>', $post_image);
    echo sprintf('<td>%s</td>', $post_tags);
    echo sprintf('<td>%s</td>', $post_date);
    echo sprintf('<td><a href=\'post.php?post=%s\' style=\'color:green\'>See Post</a></td>', $post_id);
    echo sprintf('<td><a href=\'editposts.php?id=%s\'><span class=\'glyphicon glyphicon-edit\' style=\'color: #265a88;\'></span></a></td>', $post_id);
    echo sprintf('<td><a onClick="javascript: return confirm(\'Are you sure you want to delete this post?\')" href=\'?del=%s\'><i class=\'fa fa-times\' style=\'color: red;\'></i>delete</a></td>', $post_id);

    echo "</tr>";

}
}
else {
    echo "<script>alert('You have not posted any news yet! Start Posting now');
    window.location.href= 'publishnews.php';</script>";
}
?>
 </tbody>
            </table>
</form>
</div>
</div>
</div>
<?php
    if (isset($_GET['del'])) {
        $post_del = mysqli_real_escape_string($conn , (string) $_GET['del']);
        $del_query = sprintf('DELETE FROM posts WHERE id=\'%s\' AND author=\'%s\'', $post_del, $currentuser);
        ($run_del_query = mysqli_query($conn, $del_query)) || die (mysqli_error($conn));
        if (mysqli_affected_rows($conn) > 0) {
            echo "<script>alert('post deleted successfully');
            window.location.href='posts.php';</script>";
        }
        else {
         echo "<script>alert('error occured.try again!');</script>";   
        }
        }
        ?>
<?php    
}
?>
        </div>
    </div>
</div>
</div>
</div>
 <script src="js/jquery.js"></script>

    
    <script src="js/bootstrap.min.js"></script>

</body>

</html


