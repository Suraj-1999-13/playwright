<?php

declare(strict_types=1);

use Rector\Config\RectorConfig;

return RectorConfig::configure()
    ->withImportNames(removeUnusedImports: true)
    ->withPaths([
        __DIR__ . '/admin',
        __DIR__ . '/GUMP-master',
        __DIR__ . '/includes',
    ])
    ->withRootFiles()
    ->withPhpSets(php82: true)
    ->withPreparedSets(
        deadCode: true,
        codeQuality: true,
        codingStyle: true,
        earlyReturn: true,
        naming: true,
        typeDeclarations: true,
        privatization: true,
        rectorPreset: true
    );
