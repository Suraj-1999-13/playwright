-- Active: 1721658530149@@127.0.0.1@3306@aguila
CREATE TABLE users (
    id_user INT AUTO_INCREMENT PRIMARY KEY,
    firstname VARCHAR(255) NOT NULL,
    lastname VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    address TEXT,
    city VARCHAR(255),
    state VARCHAR(255),
    contactno VARCHAR(50),
    qualification VARCHAR(255),
    stream VARCHAR(255),
    passingyear DATE, -- Change to VARCHAR(4) to store year as string
    dob DATE,
    age INT,
    designation VARCHAR(255),
    resume VARCHAR(255),
    hash VARCHAR(255),
    aboutme TEXT,
    skills TEXT,
    active TINYINT(1) DEFAULT 1, -- Add this line
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


CREATE TABLE countries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL
);

CREATE TABLE states (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    country_id INT,
    FOREIGN KEY (country_id) REFERENCES countries(id)
);

CREATE TABLE cities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    state_id INT,
    FOREIGN KEY (state_id) REFERENCES states(id)
);

CREATE TABLE company (
    id_company INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    companyname VARCHAR(255) NOT NULL,
    website VARCHAR(255),
    email VARCHAR(255) NOT NULL UNIQUE,
    aboutme TEXT,
    password VARCHAR(255) NOT NULL,
    contactno VARCHAR(15),
    country VARCHAR(255),
    state VARCHAR(255),
    city VARCHAR(255),
    logo VARCHAR(255),
    active TINYINT(1) DEFAULT 1, 
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


INSERT INTO countries (name) VALUES ('United States');
INSERT INTO countries (name) VALUES ('Canada');
INSERT INTO countries (name) VALUES ('United Kingdom');
INSERT INTO countries (name) VALUES ('Australia');
INSERT INTO countries (name) VALUES ('Germany');
INSERT INTO countries (name) VALUES ('France');
INSERT INTO countries (name) VALUES ('India');


-- States for United States (country_id = 1)
INSERT INTO states (name, country_id) VALUES ('California', 1);
INSERT INTO states (name, country_id) VALUES ('Texas', 1);
INSERT INTO states (name, country_id) VALUES ('New York', 1);
INSERT INTO states (name, country_id) VALUES ('Florida', 1);
INSERT INTO states (name, country_id) VALUES ('Illinois', 1);

-- States for Canada (country_id = 2)
INSERT INTO states (name, country_id) VALUES ('Ontario', 2);
INSERT INTO states (name, country_id) VALUES ('Quebec', 2);
INSERT INTO states (name, country_id) VALUES ('British Columbia', 2);
INSERT INTO states (name, country_id) VALUES ('Alberta', 2);
INSERT INTO states (name, country_id) VALUES ('Manitoba', 2);


INSERT INTO cities (name, state_id) VALUES ('Los Angeles', 1);
INSERT INTO cities (name, state_id) VALUES ('San Francisco', 1);
INSERT INTO cities (name, state_id) VALUES ('San Diego', 1);

INSERT INTO cities (name, state_id) VALUES ('Houston', 2);
INSERT INTO cities (name, state_id) VALUES ('Dallas', 2);
INSERT INTO cities (name, state_id) VALUES ('Austin', 2);

CREATE TABLE job_post (
    id_jobpost INT AUTO_INCREMENT PRIMARY KEY,
    id_company INT NOT NULL,  -- Assuming this links to a company in the companies table
    jobtitle VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    minimumsalary DECIMAL(10, 2) NOT NULL,
    maximumsalary DECIMAL(10, 2) NOT NULL,
    experience INT NOT NULL,
    qualification VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_jobpost) REFERENCES company(id_company) ON DELETE CASCADE
);


CREATE TABLE apply_job_post (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_jobpost INT NOT NULL,
    id_company INT NOT NULL,
    id_user INT NOT NULL,
    applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_jobpost) REFERENCES job_post(id_jobpost) ON DELETE CASCADE,
    FOREIGN KEY (id_company) REFERENCES company(id_company) ON DELETE CASCADE,
    FOREIGN KEY (id_user) REFERENCES users(id_user) ON DELETE CASCADE
);

