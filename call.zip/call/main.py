import json
from subprocess import Popen, PIPE

# Function to run Ruby code from Python
def run_ruby_code(code):
    process = Popen(['ruby'], stdin=PIPE, stdout=PIPE, stderr=PIPE)
    stdout, stderr = process.communicate(input=code.encode('utf-8'))
    return stdout.decode('utf-8'), stderr.decode('utf-8')

# Ruby code to extract method definitions and calls using Ruby's Parser
ruby_script = '''
require 'ruby_parser'

class CallGraphGenerator
  def initialize(code)
    @code = code
    @parser = RubyParser.new
    @call_graph = {}
  end

  def generate_call_graph
    ast = @parser.parse(@code)
    traverse_ast(ast)
    @call_graph
  end

  def traverse_ast(ast)
    case ast[0]
    when :defn
      method_name = ast[1]
      @call_graph[method_name] ||= []
      extract_method_calls(ast[3]).each do |called_method|
        @call_graph[method_name] << called_method
      end
    else
      ast.each do |child|
        traverse_ast(child) if child.is_a?(Sexp)
      end
    end
  end

  def extract_method_calls(ast)
    method_calls = []
    case ast[0]
    when :call
      method_calls << ast[2]
    else
      ast.each do |child|
        method_calls.concat(extract_method_calls(child)) if child.is_a?(Sexp)
      end
    end
    method_calls
  end
end

code = <<-RUBY
def foo
  bar
end

def bar
  baz
end

def baz
end

foo
RUBY

generator = CallGraphGenerator.new(code)
'''

# Run the Ruby script and capture the output
output, error = run_ruby_code(ruby_script)
print(output)

# if error:
#     print("Error:", error)
# else:
#     call_graph_data = json.loads(output)
#     # Save the call graph data as JSON
#     with open('call_graph.json', 'w') as f:
#         json.dump(call_graph_data, f, indent=4)

#     print("Call graph data saved to call_graph.json")
