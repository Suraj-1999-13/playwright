# dir1/file2.rb
module Dir1
  class ClassB
    def method_b
      puts "Inside method_b"
      Dir2::ClassD.new.method_d
    end
  end
end
