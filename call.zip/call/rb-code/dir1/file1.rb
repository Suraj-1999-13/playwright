# dir1/file1.rb
module Dir1
  class ClassA
    def method_a
      puts "Inside method_a"
      Dir2::ClassC.new.method_c
    end
  end
end
