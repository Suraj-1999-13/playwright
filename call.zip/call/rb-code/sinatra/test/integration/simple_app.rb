require "bundler/setup"
require "sinatra"

get "/" do
  "OK"
end
