# frozen_string_literal: true

source 'https://rubygems.org'

gemspec path: File.join('..', '..')
