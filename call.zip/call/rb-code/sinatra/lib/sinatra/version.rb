# frozen_string_literal: true

module Sinatra
  VERSION = '4.0.0'
end
