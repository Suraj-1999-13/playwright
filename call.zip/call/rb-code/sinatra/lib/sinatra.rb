# frozen_string_literal: true

require 'sinatra/main'

enable :inline_templates
