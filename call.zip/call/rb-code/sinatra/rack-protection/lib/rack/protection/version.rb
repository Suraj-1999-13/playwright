# frozen_string_literal: true

module Rack
  module Protection
    VERSION = '4.0.0'
  end
end
