# frozen_string_literal: true

module Sinatra
  module Contrib
    VERSION = '4.0.0'
  end
end
