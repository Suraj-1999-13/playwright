# dir2/file3.rb
module Dir2
  class ClassC
    def method_c
      puts "Inside method_c"
      Dir1::ClassB.new.method_b
    end
  end
end
