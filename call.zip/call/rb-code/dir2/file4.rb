# dir2/file4.rb
module Dir2
  class ClassD
    def method_d
      puts "Inside method_d"
    end
  end
end
