# main.rb
require_relative 'dir1/file1'
require_relative 'dir1/file2'
require_relative 'dir2/file3'
require_relative 'dir2/file4'

# Entry point for the call graph
Dir1::ClassA.new.method_a
