// Load JSON data from an external file
d3.json("../data/call_graph.json")
  .then((data) => {
    const files = d3.groups(data.nodes, (d) => d.file);
    const nodes = data.nodes;
    const edges = data.edges;

    // Create a container for the boxes
    const container = d3.select("#container");

    // Create an SVG container for the lines
    const svg = d3.select("#svg-container");

    // Create a box for each file and add functions
    files.forEach(([fileName, functions]) => {
      const fileBox = container
        .append("div")
        .attr("class", "file-box collapsed")
        .attr("data-file", fileName);

      fileBox
        .append("div")
        .attr("class", "file-title")
        .text(fileName)
        .on("click", function () {
          const isCollapsed = fileBox.classed("collapsed");
          fileBox
            .classed("collapsed", !isCollapsed)
            .classed("expanded", isCollapsed);
        });

      functions.forEach((func) => {
        fileBox
          .append("div")
          .attr("class", "function")
          .attr("data-id", func.id)
          .attr("data-file", fileName)
          .text(func.label)
          .style("display", "none") // Initially hide functions
          .on("click", function () {
            handleFunctionClick(func.id);
          });
      });
    });

    d3.selectAll(".file-title").on("click", function () {
      const parentBox = d3.select(this.parentNode);
      const isCollapsed = parentBox.classed("collapsed");

      parentBox
        .classed("collapsed", !isCollapsed)
        .classed("expanded", isCollapsed);

      parentBox
        .selectAll(".function")
        .style("display", isCollapsed ? "block" : "none");
    });

    // After the DOM is rendered, calculate and draw lines
    function drawEdges() {
      edges.forEach((edge) => {
        // Skip drawing the direct edge from function_a to function_c
        if (edge.from === "function_a" && edge.to === "function_c") {
          return;
        }

        const sourceNode = nodes.find((node) => node.id === edge.from);
        const targetNode = nodes.find((node) => node.id === edge.to);

        if (sourceNode && targetNode) {
          const sourceElem = document.querySelector(
            `.function[data-id='${edge.from}']`
          );
          const targetElem = document.querySelector(
            `.function[data-id='${edge.to}']`
          );

          if (sourceElem && targetElem) {
            const sourceRect = sourceElem.getBoundingClientRect();
            const targetRect = targetElem.getBoundingClientRect();

            // Calculate the positions
            const sourcePos = {
              x: sourceRect.left + sourceRect.width / 2 + window.scrollX,
              y: sourceRect.top + sourceRect.height / 2 + window.scrollY,
            };
            const targetPos = {
              x: targetRect.left + targetRect.width / 2 + window.scrollX,
              y: targetRect.top + targetRect.height / 2 + window.scrollY,
            };

            // Draw the line
            svg
              .append("line")
              .attr("x1", sourcePos.x)
              .attr("y1", sourcePos.y)
              .attr("x2", targetPos.x)
              .attr("y2", targetPos.y)
              .attr("stroke", "#999")
              .attr("stroke-width", 2);
          }
        }
      });
    }

    // Call drawEdges after a small delay to ensure all elements are rendered
    setTimeout(drawEdges, 100);

    function highlightConnectedFunctions(functionId) {
      // Reset all functions and file boxes to default style
      d3.selectAll(".function").style("background-color", function () {
        return d3.select(this).attr("data-file") === "unknown" ? "#FFB3BA" : "";
      });

      d3.selectAll(".file-box").classed("highlighted", false);

      // Highlight the clicked function
      const clickedFunction = d3.select(`.function[data-id='${functionId}']`);
      if (!clickedFunction.empty()) {
        clickedFunction.style("background-color", "rgb(77, 228, 213)");
        const clickedFileBox = d3.select(
          `.file-box[data-file='${clickedFunction.attr("data-file")}']`
        );
        if (!clickedFileBox.empty()) {
          clickedFileBox.classed("highlighted", true);
        } else {
          console.error(
            "No file box found for data-file: " +
              clickedFunction.attr("data-file")
          );
        }
      }

      // Highlight connected functions and their file boxes
      edges.forEach((edge) => {
        if (edge.from === functionId) {
          const toFunction = d3.select(`.function[data-id='${edge.to}']`);
          if (!toFunction.empty()) {
            toFunction.style("background-color", "rgb(42, 62, 141)");
            const fileBox = d3.select(
              `.file-box[data-file='${toFunction.attr("data-file")}']`
            );
            if (!fileBox.empty()) {
              fileBox.classed("highlighted", true);
            } else {
              console.error(
                "No file box found for data-file: " +
                  toFunction.attr("data-file")
              );
            }
          }
        }

        if (edge.to === functionId) {
          const fromFunction = d3.select(`.function[data-id='${edge.from}']`);
          if (!fromFunction.empty()) {
            fromFunction.style("background-color", "rgb(6, 91, 6)");
            const fileBox = d3.select(
              `.file-box[data-file='${fromFunction.attr("data-file")}']`
            );
            if (!fileBox.empty()) {
              fileBox.classed("highlighted", true);
            } else {
              console.error(
                "No file box found for data-file: " +
                  fromFunction.attr("data-file")
              );
            }
          }
        }
      });
    }

    // Handle function click event
    function handleFunctionClick(functionId) {
      highlightConnectedFunctions(functionId);

      container.select(".file-box[data-file='unknown']").remove();

      const outgoingEdges = edges.filter((edge) => edge.from === functionId);
      const unknownFunctions = [];

      outgoingEdges.forEach((edge) => {
        let targetFunction = nodes.find((node) => node.id === edge.to);

        if (!targetFunction) {
          targetFunction = {
            id: edge.to,
            label: edge.to,
            file: "unknown",
          };
          unknownFunctions.push(targetFunction);
        }
      });

      if (unknownFunctions.length > 0) {
        const unknownFileBox = container
          .append("div")
          .attr("class", "file-box")
          .attr("data-file", "unknown");

        unknownFileBox
          .append("div")
          .attr("class", "file-title")
          .text("unknown");

        unknownFunctions.forEach((func) => {
          unknownFileBox
            .append("div")
            .attr("class", "function1")
            .attr("data-id", func.id)
            .attr("data-file", "unknown")
            .text(func.label)
            .style("background-color", "#FFB3BA")
            .on("click", function () {
              handleFunctionClick(func.id);
            });
        });
      }

      // Redraw edges to include new unknown functions
      svg.selectAll("line").remove();
      drawEdges();
    }
  })
  .catch((error) => {
    console.error("Error loading JSON data:", error);
  });
